package com.baidu.mobstat.demo;

public class Conf {
    public static final String TAG = "Baidu Mobstat";
}
