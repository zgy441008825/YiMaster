package com.baidu.mobstat.demo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.baidu.mtjstatsdk.StatSDKService;

public class DemoActivity3 extends Activity {
    /** Called when the activity is first created. */

    private Button btnPre;
    private Button btnNext;

    @Override
    public void onCreate(Bundle savedInstanceState) {

        Log.i(Conf.TAG, "DemoActivity3.OnCreate()");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout3);

        btnPre = (Button) findViewById(R.id.layout3_btn1);
        btnNext = (Button) findViewById(R.id.layout3_btn2);

        btnPre.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(DemoActivity3.this, DemoActivity2.class);
                startActivity(intent);
            }
        });

        btnNext.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(DemoActivity3.this, DemoDialogActivity.class);
                startActivity(intent);
            }
        });
    }

    public void onResume() {
        Log.w(Conf.TAG, "Activity3.OnResume()");
        super.onResume();

        /**
         * 页面起始（每个Activity中都需要添加，如果有继承的父Activity中已经添加了该调用，那么子Activity中务必不能添加）
         * 不能与StatService.onPageStart一级onPageEnd函数交叉使用
         */
        // StatService.onResume(this);

        StatSDKService.onPageStart(this, "DemoActivity3p", "3ce7f4439c");
    }

    public void onPause() {
        Log.w(Conf.TAG, "Activity3.onPause()");
        super.onPause();

        /**
         * 页面结束（每个Activity中都需要添加，如果有继承的父Activity中已经添加了该调用，那么子Activity中务必不能添加）
         * 不能与StatService.onPageStart一级onPageEnd函数交叉使用
         */
        // StatService.onPause(this);
        StatSDKService.onPageEnd(this, "DemoActivity3p", "3ce7f4439c");
    }
}