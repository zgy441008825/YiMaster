package com.baidu.appx.demo;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Locale;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.baidu.appx.BDBannerAd;
import com.baidu.appx.BDInterstitialAd;
import com.baidu.appx.BDSplashAd;
import com.baidu.appx.BaiduAppX;

public class MainActivity extends Activity {
	public  static final String SDK_APP_KEY 		= "rGygF66DB7WucxyWzdLxWGDybRP2wmjM";
	private String SDK_BANNER_AD_ID = "sI6hqkhslxHLhwhVNkphIsMC";
	private String SDK_SPLASH_AD_ID	= "GnyUDXqyGYDETbhHS2Qc7XBm";
	private String SDK_INTERSTITIAL_AD_ID = "ntuHx5sTGGniFdR0eubEH76c";
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		setTitle(getTitle() + " V" + BaiduAppX.version());
    }
    
    private BDBannerAd	bannerview;
    public void showBanner(View v) {
    	if (null == bannerview) {
			println("---- bannerAd start to show ----");
			bannerview = new BDBannerAd(this, SDK_APP_KEY, SDK_BANNER_AD_ID);
			bannerview.setAdSize(BDBannerAd.SIZE_FLEXIBLE);
			bannerview.setAdListener(new AdListener("Banner"));
			ViewGroup  container = (ViewGroup)findViewById(R.id.adview_container);
			container.addView(bannerview);
		}
    	else {
    		println("---- bannerAd is showing, should hide first");
    	}
    }

    public void hideBanner(View v) {
    	if (bannerview != null) {
			ViewGroup  container = (ViewGroup)findViewById(R.id.adview_container);
			container.removeAllViews();
			bannerview.destroy();
			bannerview = null;
			println("---- bannerAd is hidden ----");
		}
    	else {
			println("---- bannerAd not found ----");
    	}
    }

    private BDInterstitialAd	interstitialAd;
    public void loadInterstitial(View v) {
		println("---- interstitialAd is loading ----");
    	if (null == interstitialAd) {
			interstitialAd = new BDInterstitialAd(this, SDK_APP_KEY, SDK_INTERSTITIAL_AD_ID);
			interstitialAd.setAdListener(new AdListener("Interstitial"));
		}
    	interstitialAd.loadAd();
    }

    public void showInterstitial(View v) {
    	if (null == interstitialAd || !interstitialAd.isLoaded()) {
    		println("---- interstitialAd is not ready ----");
		}
    	else {
			println("---- interstitialAd start to show ----");
    		interstitialAd.showAd();
    	}
    }

    public void clearLog(View v) {
    	if (logview != null) {
			logview.setText("");
		}
    }

    public void showNativeAd(View v) {
		Intent intent = new Intent(this, NativeActivity.class);
		startActivity(intent);
    }
    
    private BDSplashAd splashAd = null;
    private void createSplashAd() {
    	if (null == splashAd) {
    		splashAd = new BDSplashAd(this, SDK_APP_KEY, SDK_SPLASH_AD_ID);
    		splashAd.setAdListener(new AdListener("Splash"));
    	}
    }
    public void loadSplashAd(View v) {
    	createSplashAd();
    	splashAd.loadAd();
		println("---- splash ad is loading");
    }
    
    public void showSplashAd(View v) {
    	createSplashAd();
    	if (splashAd.isLoaded()) {
        	splashAd.showAd();
		}
    	else {
			println("---- splash ad is not ready");
    	}
    }
    
	private TextView  logview;
	@SuppressLint("InlinedApi") 
	private void println(String tag, String msg) {
		if (null == logview) {
			logview = (TextView)findViewById(R.id.logview);
		}
		logview.append("\n" + getCurrentDate() + tag + msg);
	}
	
	private void println(String msg) {
		println("", msg);
	}
	
	private String getCurrentDate() {
	    Locale fmtLocal = getApplicationContext().getResources().getConfiguration().locale;
	    Date now = new Date(System.currentTimeMillis());
	    SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss.SSS  ", fmtLocal);  
	    return sdf.format(now);
	}

	@Override
	protected void onDestroy() {
		if (bannerview != null) {
			bannerview.destroy();
		}
		if (interstitialAd != null) {
			interstitialAd.destroy();
		}
		if (splashAd != null) {
			
		}
		
		super.onDestroy();
	}
	
	private class AdListener implements  BDBannerAd.BannerAdListener, BDInterstitialAd.InterstitialAdListener, BDSplashAd.SplashAdListener {
		private String stringTag;
		public AdListener(String tag) {
			this.stringTag = tag;
		}
		
		@Override
		public void onAdvertisementDataDidLoadFailure() {
			MainActivity.this.println(stringTag, "    ad did load failure");
		}

		@Override
		public void onAdvertisementDataDidLoadSuccess() {
			MainActivity.this.println(stringTag, "    ad did load success");
		}

		@Override
		public void onAdvertisementViewDidClick() {
			MainActivity.this.println(stringTag, "    ad view did click");
		}

		@Override
		public void onAdvertisementViewDidShow() {
			MainActivity.this.println(stringTag, "    ad view did show");
		}

		@Override
		public void onAdvertisementViewWillStartNewIntent() {
			MainActivity.this.println(stringTag, "    ad view will new intent");
		}

		@Override
		public void onAdvertisementViewDidHide() {
			MainActivity.this.println(stringTag, "    ad view did hide");
		}
		
	}
}
