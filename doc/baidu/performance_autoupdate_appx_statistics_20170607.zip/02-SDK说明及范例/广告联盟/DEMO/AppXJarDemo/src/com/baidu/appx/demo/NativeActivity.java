package com.baidu.appx.demo;

import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.baidu.appx.BDAppWallAd;
import com.baidu.appx.BDNativeAd;
import com.baidu.appx.BDNativeAd.AdInfo;

public class NativeActivity extends Activity {
	private String SDK_APPWALL_AD_ID = "s7WGeNKlSdXD3vy3Pr22y2eP";
	private String SDK_NATIVE_AD_ID	= "s7WGeNKlSdXD3vy3Pr22y2eP";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_native);
        nativeAd = new BDNativeAd(this, MainActivity.SDK_APP_KEY, SDK_NATIVE_AD_ID);
    }
    
	public void downloadNativeAd(View v) {
		nativeAd.loadAd();
	}
	
	public void checkNativeAd(View v) {
		String tip = nativeAd.isLoaded() ? "����Ѿ�����" : "û�з��ֹ������";
		Toast.makeText(this, tip, Toast.LENGTH_SHORT).show();
	}
	
	
	public void nativeAdDidShow(View v) {
		AdInfo adInfo = anyNativeAd();
		if (adInfo != null) {
			adInfo.didShow();
		}
	}
	
	public void nativeAdDidClick(View v) {
		AdInfo adInfo = anyNativeAd();
		if (adInfo != null) {
			adInfo.didClick();
		}
	}
	
	public void loadAppWallAd(View v) {
		if (null == appWallAd) {
			appWallAd = new BDAppWallAd(this, MainActivity.SDK_APP_KEY, SDK_APPWALL_AD_ID);
		}
		appWallAd.loadAd();
	}

	public void showAppWallAd(View v) {
		if (appWallAd != null && appWallAd.isLoaded()) {
			appWallAd.doShowAppWall();
		}
		else {
			Toast.makeText(this, "û��Ӧ��ǽ����", Toast.LENGTH_SHORT).show();
		}
	}
	
	private AdInfo  anyNativeAd() {
		ArrayList<AdInfo> allAds = nativeAd.getAdInfos();
		if (allAds.size() > 0) {
			return allAds.get(0);
		}
		return null;
	}
	
	private BDNativeAd  	nativeAd = null;
	private BDAppWallAd  	appWallAd = null;
	
	@Override
	protected void onDestroy() {
		if (nativeAd != null) {
			nativeAd.destroy();
		}
		if (appWallAd != null) {
			appWallAd.destroy();
		}
		super.onDestroy();
	}
}
