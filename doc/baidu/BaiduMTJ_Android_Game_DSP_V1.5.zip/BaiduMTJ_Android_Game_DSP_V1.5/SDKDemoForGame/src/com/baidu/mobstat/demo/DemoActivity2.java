package com.baidu.mobstat.demo;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.baidu.mtjstatsdk.StatSDKService;
import com.baidu.mtjstatsdk.game.BDGameAccountType;
import com.baidu.mtjstatsdk.game.BDGameSDK;
import com.baidu.mtjstatsdk.game.BDGender;

public class DemoActivity2 extends Activity {
    /** Called when the activity is first created. */

    private Button btn_pre;
    private Button btn_next;
    private Button setAccount;
    private Button startTask;
    private Button endTask;
    private Button failedTask;
    private Button onRechargeRequest;
    private Button onRechargeSuccess;
    private Button setGameServer;
    private Button setAnotherAcount;
    private Button onPurchase;
    private Button onUse;
    private Context context;

    @Override
    public void onCreate(Bundle savedInstanceState) {

        Log.w(Conf.TAG, "DemoActivity2.OnCreate()");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout2);
        context = this;
        btn_pre = (Button) findViewById(R.id.layout2_btn1);
        btn_next = (Button) findViewById(R.id.layout2_btn2);

        btn_pre.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(DemoActivity2.this, DemoActivity1.class);
                startActivity(intent);
            }
        });

        btn_next.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(DemoActivity2.this, DemoActivity3.class);
                startActivity(intent);
            }
        });

        setAccount = (Button) findViewById(R.id.setAccount);
        startTask = (Button) findViewById(R.id.startTask);
        endTask = (Button) findViewById(R.id.endTask);

        failedTask = (Button) findViewById(R.id.failedTask);
        onRechargeRequest = (Button) findViewById(R.id.onRechargeRequest);

        onRechargeSuccess = (Button) findViewById(R.id.onRechargeSuccess);

        setGameServer = (Button) findViewById(R.id.setGameServer);

        setAnotherAcount = (Button) findViewById(R.id.setAnotherAcount);
        // BF8BE9FCC6B3C27F353525817BD7DAA0

        onPurchase = (Button) findViewById(R.id.onPurchase);
        onUse = (Button) findViewById(R.id.onUse);

        setAccount.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                BDGameSDK.setAccount(context, "accountID2", "3ce7f4439c");
                BDGameSDK.setAccountName(context, "accountName2", "3ce7f4439c");
                BDGameSDK.setAccountType(context, BDGameAccountType.BAIDU, "3ce7f4439c");
                BDGameSDK.setAge(context, 28, "3ce7f4439c");
                BDGameSDK.setGender(context, BDGender.MALE, "3ce7f4439c");
                BDGameSDK.setLevel(context, 2, "3ce7f4439c");
                BDGameSDK.setServer(context, "国服2", "3ce7f4439c");

            }
        });
        //
        setAnotherAcount.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                BDGameSDK.setAccount(context, "accountID3", "3ce7f4439c");
                BDGameSDK.setAccountName(context, "accountName3", "3ce7f4439c");
                BDGameSDK.setAccountType(context, BDGameAccountType.BAIDU, "3ce7f4439c");
                BDGameSDK.setAge(context, 38, "3ce7f4439c");
                BDGameSDK.setGender(context, BDGender.UNKNOWN, "3ce7f4439c");
                BDGameSDK.setLevel(context, 3, "3ce7f4439c");
                BDGameSDK.setServer(context, "国服3", "3ce7f4439c");
            }
        });
        //
        startTask.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                BDGameSDK.onTaskStart("taskID", "3ce7f4439c");

            }
        });

        endTask.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                BDGameSDK.onTaskFinished("taskID", "3ce7f4439c");
                BDGameSDK.setLevel(context, 100, "3ce7f4439c");
            }
        });
        failedTask.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                BDGameSDK.onTaskFailed("taskID", "died", "3ce7f4439c");
            }
        });

        onPurchase.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                BDGameSDK.onPurchase("ppoint", 189, 10, "3ce7f4439c");
            }
        });

        onRechargeRequest.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                // ：支付途径，int值，可选值：0 : 未知；1 : App Store；2 : 百度钱包；3 : 支付宝；4 : 微信支付；<br/>
                // *
                //  5 : 网银；6 : 财付通；7 : 移动通信；8 : 联通通信；9 : 电信通信；10 : paypal。<br/>
                // *  0-100 是系统预定义的类型，101-200是用户可自定义的类型； <br/>
                // * 如果您的类型超过上述几种，可以传入101-200之间的数代表您的类型
                // ，后期可以通过在网站设置，将传入的自定义类型号进行命名定义。<br/>
                // * 注意：<br/>
                // * 传入的值超过0-200范围，则设置无效!!!!<br/>
                BDGameSDK.onRechargeRequest("orderId", "iapid", 21.5, 10000, 1,
                                "3ce7f4439c");
            }
        });

        onRechargeSuccess.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                BDGameSDK.onRechargeSuccess("orderId", "3ce7f4439c");
            }
        });

        setGameServer.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                BDGameSDK.setServer(context, "国服6", "3ce7f4439c");

            }
        });

        onUse.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                BDGameSDK.onUse("ppoint", 5, "3ce7f4439c");
            }
        });
    }

    public void onResume() {
        Log.w(Conf.TAG, "Activity2.OnResume()");
        super.onResume();
        StatSDKService.onResume(context, "3ce7f4439c");
    }

    public void onPause() {
        Log.w(Conf.TAG, "Activity2.onPause()");
        super.onPause();
        StatSDKService.onPause(context, "3ce7f4439c");
    }
}
