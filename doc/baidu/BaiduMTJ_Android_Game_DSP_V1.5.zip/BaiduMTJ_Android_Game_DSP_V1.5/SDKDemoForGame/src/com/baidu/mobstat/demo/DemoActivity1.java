package com.baidu.mobstat.demo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;

import com.baidu.mtjstatsdk.StatSDKService;
import com.baidu.mtjstatsdk.game.BDGameSDK;

public class DemoActivity1 extends Activity {
    /** Called when the activity is first created. */

    private Button btnPre;
    private Button btnNext;
    private Button btnException;
    private Button btnEvent;
    private Button btnEventDuration;
    private Button btnEventStart;
    private Button btnEventEnd;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_ACTION_BAR);
        setContentView(R.layout.layout1);

        btnPre = (Button) findViewById(R.id.layout1_btn1);
        btnNext = (Button) findViewById(R.id.layout1_btn2);
        btnException = (Button) findViewById(R.id.layout1_btn_excep);
        btnEvent = (Button) findViewById(R.id.layout1_btn_event);
        btnEventDuration = (Button) findViewById(R.id.layout1_btn_event_duration);

        btnEventStart = (Button) findViewById(R.id.layout1_btn_event_start);
        btnEventEnd = (Button) findViewById(R.id.layout1_btn_event_end);

        BDGameSDK.setOn(this, BDGameSDK.EXCEPTION_LOG, "3ce7f4439c"); // 统计崩溃信息，必须优先其他接口调用
        BDGameSDK.initGame(this, "3ce7f4439c"); // 初始化游戏统计，必须优先其他接口调用，和setOn一起调用。
        StatSDKService.setAppChannel(this, "channelapp", true, "3ce7f4439c"); // 初始化app的渠道号，优先调用，和initGame以及setOn一起调用
        StatSDKService.setDebugOn(true, "3ce7f4439c"); // 打开log调试，log的过滤标签位statsdk，可以看到发送的log
        StatSDKService.setAppVersionName("1.5", "3ce7f4439c"); // 设置APP的版本号，必须优先调用，与上面几个初始化接口一起调用。

        BDGameSDK.setAccount(this, "accountID0", "3ce7f4439c"); // 在游戏首页，需要添加游戏账户的id，如果游戏开始，没有设置游戏的ID，那么游戏数据无法统计到。可以
        // 如果游戏没有账户，请使用IMEI号或者SDK提供的cuid来填充StatSDKService.getCuid(this);

        btnPre.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {

                Intent intent = new Intent();
                intent.setClass(DemoActivity1.this, DemoActivity3.class);

                DemoActivity1.this.startActivity(intent);
            }
        });

        btnNext.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(DemoActivity1.this, DemoActivity2.class);
                DemoActivity1.this.startActivity(intent);
            }
        });

        btnException.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                Log.w(Conf.TAG, 10 / 0 + "");
            }
        });

        btnEvent.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {

                StatSDKService.onEvent(DemoActivity1.this.getApplicationContext(),
                        "registered id", "pass", 1,
                        "3ce7f4439c");
            }
        });

        /**
         * 自定义事件的第一种方法，写入某个事件的持续时长
         */
        btnEventDuration.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {

                // 事件id（"registered id"）的事件pass，其时长持续100毫秒
                StatSDKService.onEventDuration(DemoActivity1.this, "registered id",
                        "pass", 100, "3ce7f4439c");

            }
        });

        /*
         * 自定义事件的第二种方法，自己定义该事件的起始时间和结束时间
         */
        btnEventStart.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {

                // 事件id（"registered id"）的事件pass，其时长持续10毫秒
                StatSDKService.onEventStart(DemoActivity1.this, "registered id", 
                        "pass", "3ce7f4439c"); // 必须和onEventEnd共用才行

            }
        });

        /*
         * 自定义事件的第二种方法，自己定义该事件的起始时间和结束时间
         */
        btnEventEnd.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {

                // 事件id（"registered id"）的事件pass，其时长持续10毫秒
                StatSDKService.onEventEnd(DemoActivity1.this, "registered id", 
                        "pass", "3ce7f4439c"); // 必须和onEventStart共用才行
            }
        });
    }

    public void onResume() {
        Log.w(Conf.TAG, "Activity1.OnResume()");
        super.onResume();

        /**
         * 页面起始（每个Activity中都需要添加，如果有继承的父Activity中已经添加了该调用，那么子Activity中务必不能添加）
         * 不能与StatService.onPageStart一级onPageEnd函数交叉使用
         */
        StatSDKService.onResume(this, "3ce7f4439c");
    }

    public void onPause() {
        Log.w(Conf.TAG, "Activity1.onPause()");
        super.onPause();

        /**
         * 页面结束（每个Activity中都需要添加，如果有继承的父Activity中已经添加了该调用，那么子Activity中务必不能添加）
         * 不能与StatService.onPageStart一级onPageEnd函数交叉使用
         */
        StatSDKService.onPause(this, "3ce7f4439c");
    }
}

// /~ 