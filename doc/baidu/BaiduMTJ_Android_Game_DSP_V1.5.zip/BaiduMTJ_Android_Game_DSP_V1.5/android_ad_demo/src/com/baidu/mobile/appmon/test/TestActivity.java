package com.baidu.mobile.appmon.test;

/***************************************************************************
 *  
 *  Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *  Author: wangbaowei@baidu.com
 *  ActiveManager.java 2015-04-07
 *  
 **************************************************************************/

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.baidu.mobile.appmon.ActiveManager;
import com.baidu.mtjstatsdk.StatSDKService;

public class TestActivity extends Activity {
    EditText etWord;
    Button btnSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout rlMain = new LinearLayout(this);
        rlMain.setOrientation(LinearLayout.VERTICAL);
        TextView desc = new TextView(this);
        desc.setText("应用打开成功。请回到微任务执行后续步骤");
        rlMain.addView(desc);
        StatSDKService.setDebugOn(true, "4333ffe16d");
        
        ActiveManager.sendActive(this.getApplicationContext(), "4333ffe16d");
        
        desc.setText("已经收到的消息有:");
        final TextView tv = new TextView(this);
        final SharedPreferences sp = getSharedPreferences("__appmon_sdk",
                Context.MODE_PRIVATE);
        String str = sp.getString("sk", "");
        tv.setText(str);
        rlMain.addView(tv);
        Button btn = new Button(this);
        btn.setText("Clear!");
        btn.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                Editor edt = sp.edit();
                edt.clear();
                edt.commit();
                tv.setText("");
            }

        });
        rlMain.addView(btn);
        setContentView(rlMain);
    }

    @Override
    protected void onPause() {
        super.onPause();
        StatSDKService.onPause(this, "4333ffe16d");
    }

    @Override
    protected void onResume() {
        super.onResume();
        StatSDKService.onResume(this, "4333ffe16d");
    }

}
